

# import hashlib
# import os
# # 准备二进制数据
#
# fp = open("E:/python/isuzu/FFXIV_Setup_2019.05.30.exe","rb")
# data = fp.read()
# fp.close()
# # 实例化算法对象
# h = hashlib.sha256(data)
# # 获取16进制字符串
# result = h.hexdigest()
#
# size = os.path.getsize("E:/python/isuzu/FFXIV_Setup_2019.05.30.exe")
#


# import math
#
# print(math.sqrt(8))
#
# list = [1,2,3,4,5,6]
# list[2] = 9
# list1 = [[x*y for x in list] for y in list]
# print(list1)
import time
L= [1,2,3,5,6]
L1=''.join([str(i) for i in L])
print(str(L1))

now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))  #获取当前时间
print(now_time)