

# li = [i**3 for i in range(1,10) if i%3==0 and i%5==1]
# print(li)

# import sys

# args= sys.argv
# print(args)
class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def rereverseList(head,new_head):
    if head is None:
        return
    if head.next is None:
        new_head=head
    else :
        new_head=rereverseList(head.next,new_head)
        head.next.next = head
        head.next =None
    return new_head



