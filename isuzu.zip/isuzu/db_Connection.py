config = {
    "host":"127.0.0.1",
    "port":3306,
    "user":"root",
    "password":"root",
    "database":"its",
    "charset":"utf8"
}

# import random
# alert = '0' + str(random.randint(1, 3)) + "".join(random.choice("789") for i in range(8))
# print(alert)

# alert = '0' + '1' + "".join(random.choice("789") for i in range(8))
# print(alert)
# mileage = 95000
# mileage = hex(mileage)[2:].upper()
# print(mileage)
# if len(mileage) != 8:
#     m = (8 - len(mileage)) * str(0)
#     print(m)
# mileage = m + mileage
# print(mileage)

