import time

now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
print(now_time)

# 先转换为时间数组
timeArray = time.strptime(now_time,'%Y-%m-%d %H:%M:%S')

# 转换为时间戳
timeStamp = int(time.mktime(timeArray))
print(timeStamp)


